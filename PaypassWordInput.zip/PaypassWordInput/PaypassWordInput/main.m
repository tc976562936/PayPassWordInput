//
//  main.m
//  PaypassWordInput
//
//  Created by 时代科技 on 2018/5/18.
//  Copyright © 2018年 timesScience. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
