//
//  PayPasswordView.h
//  PasswordDemo
//
//  Created by Tc on 2018/5/17.
//

#import <UIKit/UIKit.h>
@protocol PayPasswordViewDelegate<NSObject>

//重新输入(清除密码)
- (void)againInput:(UIButton *)sender;

//关闭页面
- (void)closePasInputView:(UIButton *)sender;

@end

@interface PayPasswordView : UIView

//存放所有密码
@property (nonatomic,strong)NSMutableArray *passwords;

@property (nonatomic,weak) id<PayPasswordViewDelegate> delegate;

+ (instancetype)createView;

@end

