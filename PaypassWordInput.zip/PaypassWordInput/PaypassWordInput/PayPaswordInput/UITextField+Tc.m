
#import "UITextField+Tc.h"
#import <objc/runtime.h>

NSString * const TcTextFieldDidDeleteBackwardNotification = @"paypas";

@implementation UITextField (Tc)
+ (void)load {
    //交换2个方法中的IMP
    Method method1 = class_getInstanceMethod([self class], NSSelectorFromString(@"deleteBackward"));
    Method method2 = class_getInstanceMethod([self class], @selector(Tc_deleteBackward));
    method_exchangeImplementations(method1, method2);
}
- (void)Tc_deleteBackward {
    [self Tc_deleteBackward];
    
    if ([self.delegate respondsToSelector:@selector(textFieldDidDeleteBackward:)])
    {
        id <TcTextFieldDelegate> delegate  = (id<TcTextFieldDelegate>)self.delegate;
        [delegate textFieldDidDeleteBackward:self];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:TcTextFieldDidDeleteBackwardNotification object:self];
}
@end
