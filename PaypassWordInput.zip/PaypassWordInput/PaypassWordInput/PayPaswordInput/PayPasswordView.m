//
//  PayPasswordView.m
//  PasswordDemo
//
//  Created by Tc on 2018/5/17.
//


#import "PayPasswordView.h"
#import "UITextField+Tc.h"
#define MAX_LENGHT 1
@interface PayPasswordView()

@property (weak, nonatomic) IBOutlet UITextField *pasNumFristTf;
@property (weak, nonatomic) IBOutlet UITextField *pasNumSecondTf;
@property (weak, nonatomic) IBOutlet UITextField *pasNumThirdTf;
@property (weak, nonatomic) IBOutlet UITextField *pasNumFourthTf;
@property (weak, nonatomic) IBOutlet UITextField *pasNumFifthTf;
@property (weak, nonatomic) IBOutlet UITextField *pasNumLastTf;
//存放所有的输入框
@property (nonatomic,strong)NSMutableArray *textFields;

@end

@implementation PayPasswordView
+ (instancetype)createView {
    NSArray *nibViews = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    return nibViews.firstObject;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    //进入页面弹出键盘
    [_pasNumFristTf becomeFirstResponder];
}
//键盘正在输入
- (IBAction)pasTextFieldEditChanged:(UITextField *)sender {
    
    if (sender == self.textFields.lastObject) {
        //清空密码数组
        if (_passwords.count > 0) {
            [_passwords removeAllObjects];
        }
        //当输入到第六位时,收起键盘,关闭所有键盘的输入
        [sender resignFirstResponder];
        [_textFields enumerateObjectsUsingBlock:^(UITextField  *_Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.enabled = NO;
            //获取到密码
            [self.passwords addObject:[self->_textFields[idx] text]];
        }];
        return;
    }
    if (sender.text.length == MAX_LENGHT) {
        //每个输入框输入1位自动跳转到下一个输入框
        NSInteger index = [self.textFields indexOfObject:sender];
        UITextField *nextTf = _textFields[index+1];
        
        [_textFields enumerateObjectsUsingBlock:^(UITextField  *_Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj == nextTf) {
                obj.enabled = YES;
                [obj becomeFirstResponder];
            } else {
                obj.enabled = NO;
                [obj resignFirstResponder];
            }
        }];
    }
}
//键盘即将开始编辑
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
     [self.textFields enumerateObjectsUsingBlock:^(UITextField  *_Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
         if (obj == textField) {
             obj.enabled = YES;
         } else {
             obj.enabled = NO;
         }
        }];
    return YES;
}
//删除密码
- (void)textFieldDidDeleteBackward:(UITextField *)textField {
   if (textField == _pasNumFristTf) return;
   NSInteger index = [_textFields indexOfObject:textField];
   UITextField *lastTf = _textFields[index - 1];
   lastTf.enabled = YES;
   [textField resignFirstResponder];
   [lastTf becomeFirstResponder];
   lastTf.text = @"";
}
//关闭密码输入页面
- (IBAction)closePayPasViewClick:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(closePasInputView:)]) {
        [self.delegate closePasInputView:sender];
    }
}
//重新输入
- (IBAction)againInputClick:(UIButton *)sender {
    //清空密码
    [_textFields enumerateObjectsUsingBlock:^(UITextField  *_Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.text = @"";
    }];
    [self textFieldShouldBeginEditing:_pasNumFristTf];
    [_pasNumFristTf becomeFirstResponder];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(againInput:)]) {
        [self.delegate againInput:sender];
    }
}
- (NSMutableArray *)textFields {
    if (!_textFields) {
        _textFields = [[NSMutableArray alloc] init];
        [_textFields addObjectsFromArray:@[_pasNumFristTf,_pasNumSecondTf,_pasNumThirdTf,_pasNumFourthTf,_pasNumFifthTf,_pasNumLastTf]];
    }
    return _textFields;
}
- (NSMutableArray *)passwords {
    if (!_passwords) {
        _passwords = [[NSMutableArray alloc] init];
    }
    return _passwords;
}
@end
