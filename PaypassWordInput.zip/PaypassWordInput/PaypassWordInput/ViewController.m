//
//  ViewController.m
//  PaypassWordInput
//
//  Created by 时代科技 on 2018/5/18.
//  Copyright © 2018年 timesScience. All rights reserved.
//

#import "ViewController.h"
#import "PayPasswordView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    PayPasswordView *pasInputView = [PayPasswordView createView];
    pasInputView.frame = self.view.bounds;
    [self.view addSubview:pasInputView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}

@end
